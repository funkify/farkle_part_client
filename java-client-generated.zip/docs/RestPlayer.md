# RestPlayer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** |  |  [optional]
**score** | **Integer** |  |  [optional]
**name** | **String** |  |  [optional]
