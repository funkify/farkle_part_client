# RestDices

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dices** | **List&lt;Integer&gt;** |  |  [optional]
**score** | **Integer** |  |  [optional]
